#!/usr/bin/env node
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { watch } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { DROP_FOLDERS, ensureDropTree, ingestDrop, loadDropConfig } from "../src/lib/sprites/drop.mjs";

const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const inboxRoot = path.join(repoRoot, "public", "sprites");

function args() {
  const watchMode = process.argv.includes("--watch");
  const pushFlag = process.argv.includes("--push");
  const dropArg = process.argv.find((item) => item.startsWith("--drop="));
  return { watchMode, pushFlag, dropDir: dropArg ? dropArg.slice("--drop=".length) : undefined };
}

function gitPush(copied) {
  if (!copied.length) return;
  if (!existsSync(path.join(repoRoot, ".git"))) {
    console.log("图已经拷进工程了，但这份没有 git，推不上去。");
    console.log("不要把 png 拖进 Cursor 对话，很费 token。");
    console.log("关掉这个窗口，双击 接通仓库.cmd，贴上 Create repo 的地址。");
    console.log("通了以后再开 投放.cmd，之后只需跟我说「图放好了」。");
    return;
  }
  const add = spawnSync("git", ["add", "--", "public/sprites/inbox"], { cwd: repoRoot, encoding: "utf8" });
  if (add.status !== 0) {
    console.error(add.stderr || add.stdout);
    return;
  }
  const status = spawnSync("git", ["status", "--porcelain", "--", "public/sprites/inbox"], {
    cwd: repoRoot,
    encoding: "utf8",
  });
  if (!status.stdout.trim()) {
    console.log("没有新的帧要提交。");
    return;
  }
  const commit = spawnSync("git", ["commit", "-m", "Add sprite frames from the local drop folder."], {
    cwd: repoRoot,
    encoding: "utf8",
  });
  if (commit.status !== 0) {
    console.error(commit.stderr || commit.stdout);
    console.error("提交失败：本机 git 需要 user.name / user.email。");
    return;
  }
  const push = spawnSync("git", ["push"], { cwd: repoRoot, encoding: "utf8" });
  if (push.status !== 0) {
    console.error(push.stderr || push.stdout);
    console.error("推送失败：先在网页点 Create repo，本机 git remote 指向那个仓库。");
    return;
  }
  console.log("已推到仓库。回来跟我说「图放好了」。");
}

function printSlots(dropDir) {
  console.log("");
  console.log("可用子目录：");
  for (const slot of DROP_FOLDERS) {
    const mark = slot.folder.startsWith("背景/") || slot.folder.startsWith("bg/") ? "<- background" : "";
    console.log(`  ${path.join(dropDir, ...slot.folder.split("/"))} ${mark}`);
  }
  console.log("");
  console.log("Chapter 1 background goes here:");
  console.log(`  ${path.join(dropDir, "bg", "1", "loop.png")}`);
  console.log(`  ${path.join(dropDir, "背景", "1", "loop.png")}`);
  console.log("");
}

async function run(dropDir, push) {
  await ensureDropTree(dropDir);
  const copied = await ingestDrop(dropDir, inboxRoot);
  if (!copied.length) {
    console.log(`Empty drop folder: ${dropDir}`);
    console.log("Character frames -> 走路 / 攻击 / 死亡");
    console.log("Chapter 1 background -> drop\\bg\\1\\loop.png");
    return copied;
  }
  for (const item of copied) {
    console.log(`${item.from} → public/sprites/${item.to}`);
  }
  if (push) gitPush(copied);
  return copied;
}

const flags = args();
const config = await loadDropConfig(repoRoot);
const dropDir = flags.dropDir || config.dropDir;
const push = flags.pushFlag || config.push;

await ensureDropTree(dropDir);
console.log(`投放文件夹：${dropDir}`);
printSlots(dropDir);

if (flags.watchMode) {
  let timer;
  const kick = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      void run(dropDir, push).catch((error) => console.error(error));
    }, 500);
  };
  watch(dropDir, { recursive: true }, kick);
  console.log("正在监视。生成图扔进来就会进 inbox" + (push ? " 并 git push。" : "。加 --push 会提交到仓库。"));
  kick();
} else {
  await run(dropDir, push);
}
