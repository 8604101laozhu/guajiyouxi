Fix Windows drop / GitHub push
==============================

Problem:
- Old Chinese 投放.cmd breaks under Windows GBK (plorer / broken echo).
- Old GitHub scripts/drop.mjs does NOT route drop\bg\1\ so loop.png never pushes.

Install into G:\guajiyouxi\guajiyouxi :
1. Close the black watch window.
2. Unzip this archive into the project root (overwrite).
3. Double-click drop.cmd (English name) OR fix-drop.cmd
4. Explorer opens drop\bg\1\ — put loop.png there (3840x720).
5. Black window should show: bg/1/loop.png -> .../chapter-1/loop.png and git push.
6. Tell the agent: 图放好了

Emergency without watch: double-click push-bg.cmd
